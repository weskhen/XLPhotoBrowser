//
//  XLPhotoBrowserView.h
//  XLPhotoBrower
//
//  Created by wujian on 2017/12/20.
//  Copyright © 2017年 xiaolian.Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol XLPhotoBrowserViewDelegate <NSObject>

- (void)handleSingleTap:(UITapGestureRecognizer *)recognizer;

@optional
- (void)handleDoubleTap:(UITapGestureRecognizer *)recognizer;

-(void)handleLongTap:(UILongPressGestureRecognizer *)recognizer;

- (void)handlePanGestureBegin:(UIPanGestureRecognizer *)recognizer;

- (void)handlePanGestureEnd:(UIPanGestureRecognizer *)recognizer isDissmiss:(BOOL)isDissmiss;

- (void)handlePanGestureMove:(CGFloat)comProgress;

@end
@interface XLPhotoBrowserView : UIView
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIImageView *imageview;
@property (nonatomic, assign) CGFloat progress;

@property (nonatomic, assign) NSUInteger viewTag;
@property (nonatomic, assign) BOOL beginLoadingImage; //是否正在loading

@property (nonatomic, weak) id <XLPhotoBrowserViewDelegate> delegate;

@property (nonatomic, copy) void (^singleTapBlock)(UITapGestureRecognizer *recognizer);
@property (nonatomic, copy) void (^longTabBlock)(UILongPressGestureRecognizer *recognizer);
/** 图片拖动进度 dragProgress 0代表开始 end 是否结束 **/
@property (nonatomic, copy) void (^panBeginBlock)(UIPanGestureRecognizer *recognizer);
@property (nonatomic, copy) void (^panEndBlock)(UIPanGestureRecognizer *recognizer, BOOL isDissmiss);
@property (nonatomic, copy) void (^panMoveBlock)(CGFloat dragProgress);

- (void)setImageWithURL:(NSURL *)url placeholderImage:(UIImage *)placeholder;

- (void)starLoadingContentView;

- (void)removeNoNeedToLoadConentView;

@end
