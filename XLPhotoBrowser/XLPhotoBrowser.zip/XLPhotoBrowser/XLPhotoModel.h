//
//  XLPhotoModel.h
//  XLPhotoBrower
//
//  Created by wujian on 2017/12/20.
//  Copyright © 2017年 xiaolian.Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XLPhotoModel : NSObject
/** 缩略图的图片url **/
@property (nonatomic, copy) NSString *smallImageURL;

/** 大图的图片url **/
@property (nonatomic, copy) NSString *bigImageURL;
/**
 *  快速创建图片模型
 *
 *  @param smallImageURL 缩略图的url  smallImageURL
 *  @param bigImageURL   大图的url    bigImageURL
 *
 *  @return 返回图片模型  Engilsh:Return to picture model
 */
-(instancetype)initWithsmallImageURL:(NSString *)smallImageURL bigImageURL:(NSString *)bigImageURL;
@end
